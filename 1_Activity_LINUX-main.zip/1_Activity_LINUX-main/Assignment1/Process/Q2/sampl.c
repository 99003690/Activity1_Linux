#include <stdio.h>
int main() 
{
  int a, b, c, d;
  a = 50;
  b = 60;
  d = a*b;
  printf("d=%d\n",d);
  return 0;
}