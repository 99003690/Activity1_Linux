#include "fun.h"
int multiply(int x, int y) {
  return x * y;
}