#ifndef MYSTRING_H_INCLUDED
#define MYSTRING_H_INCLUDED

#include <stdio.h>
#include <stdlib.h>

char* mystrcpy(char*,const char*);
int mystrlen(const char*);
char* mystrcat(char*,const char*);
int mystrcmp(const char*,const char*);


#endif // MYSTRING_H_INCLUDED
